# Third-party notices

The Barmous Compliance plugin and connector packages include the following third-party software. Each component remains subject to its own license.

## Product marks used on the download page

- The OpenAI mark is provided by OpenAI and is used only to identify the Codex setup option. OpenAI and its marks remain the property of OpenAI. Source and usage terms: <https://openai.com/brand/>.
- The Claude spark is provided in Anthropic's official media press kit and is used only to identify the Claude Code setup option. Anthropic, Claude, and their marks remain the property of Anthropic. Source: <https://www.anthropic.com/news>.
- The Cursor and Perplexity SVG icon data is sourced from Simple Icons 16.28.0 and distributed under CC0 1.0 Universal. Source: <https://github.com/simple-icons/simple-icons/tree/16.28.0>. The CC0 dedication applies to the icon data and does not grant trademark rights in the identified products.
- The Google Antigravity full-color icon is provided by Google on the official Antigravity brand site and is used only to identify the Antigravity setup option. Source: <https://antigravity.google/assets/image/brand/antigravity-icon__full-color.png>.
- The Kimi Code storefront icon is sourced from Moonshot AI's official Kimi Code repository and is used only to identify the compatible Kimi Code setup option. Source: <https://github.com/MoonshotAI/kimi-code/blob/02c026d4871a14cd5e7b4b0e0ec71ba815f643df/apps/vscode/resources/kimi-icon-storefront.png>.
- The Hermes icon is sourced from Nous Research's official Hermes Agent repository and is used only to identify the compatible Hermes setup option. Source: <https://github.com/NousResearch/hermes-agent/blob/ea0d54db1d22416ea07cd98abfb5d6e160aa86c9/website/static/img/apple-touch-icon.png>.

These product marks identify compatible setup options and do not imply endorsement of Barmous Compliance by their owners.

## CC0 1.0 Universal component

Simple Icons 16.28.0 icon data for Cursor and Perplexity is dedicated to the public domain under CC0 1.0 Universal. The complete legal code is available at <https://creativecommons.org/publicdomain/zero/1.0/legalcode>.

## SIL Open Font License component

The download page self-hosts Noto Sans Variable, Copyright 2022 The Noto Project Authors. It is distributed under the SIL Open Font License, Version 1.1. The complete license is included at [fonts/OFL.txt](./fonts/OFL.txt).

## MIT-licensed components

- `@modelcontextprotocol/sdk` 1.30.0 — Copyright 2024 Anthropic PBC
- `ajv` — Copyright 2015-2021 Evgeny Poberezkin
- `ajv-formats` — Copyright 2020 Evgeny Poberezkin
- `fast-deep-equal` — Copyright 2017 Evgeny Poberezkin
- `json-schema-traverse` — Copyright 2017 Evgeny Poberezkin
- `zod` 4.4.3 — Copyright 2025 Colin McDonnell
- Kimi Code storefront icon — Copyright 2026 Moonshot AI
- Hermes icon — Copyright 2025 Nous Research

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## BSD-3-Clause component

`fast-uri`

Copyright (c) 2011-2021, Gary Court until https://github.com/garycourt/uri-js/commit/a1acf730b4bba3f1097c9f52e7d9d3aba8cdcaae
Copyright (c) 2021-present The Fastify team <https://github.com/fastify/fastify#team>
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
- Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
- The names of any contributors may not be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The complete list of contributors can be found at:

- https://github.com/garycourt/uri-js/graphs/contributors

## ISC-licensed component

`zod-to-json-schema` — Copyright 2020 Stefan Terdell

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
