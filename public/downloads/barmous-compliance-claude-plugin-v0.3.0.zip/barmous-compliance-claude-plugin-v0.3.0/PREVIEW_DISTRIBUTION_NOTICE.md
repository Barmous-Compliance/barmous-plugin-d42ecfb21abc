# Barmous Compliance plugin preview distribution notice

This package is an evaluation preview of the Barmous Compliance integration and CLI for Claude Code. It is provided for testing by recipients who have an authorized Barmous account. No credential is included; `barmous login` issues a scoped credential after browser approval. Login supports finite lifetimes and a revocable non-expiring credential, which is the default.

No open-source license is granted for Barmous-owned code in this package. Barmous Compliance retains all rights in that code.

Do not use this preview against accounts, environments, or data you are not authorized to access.

Third-party components remain under their own licenses, reproduced in [THIRD_PARTY_NOTICES.md](./THIRD_PARTY_NOTICES.md).
