# Barmous Compliance Codex plugin

This plugin gives Codex company-scoped, read-only access to released compliance data in Barmous. It bundles a self-contained local MCP server and five reusable compliance skills.

This download is a public-by-link evaluation preview, not an open-source release. Review the [preview distribution notice](./PREVIEW_DISTRIBUTION_NOTICE.md) and [third-party notices](./THIRD_PARTY_NOTICES.md) before use.

## Requirements

- Node.js `>=22.12 <25`
- An authorized Barmous account
- A production Barmous backend URL served over HTTPS
- A one-time, company-scoped agent token created in Barmous

The package contains no Barmous token, credential, or company data. Plain HTTP is allowed only for local development against `localhost`; never enable the insecure HTTP override for a production connection.

## Install the downloaded preview

1. Extract the ZIP to a folder you control.
2. Open PowerShell in the extracted folder.
3. Add the included marketplace and install the plugin:

   ```powershell
   $pluginRoot = (Resolve-Path ".").Path
   codex plugin marketplace add $pluginRoot
   codex plugin add barmous-company-data@barmous
   ```

4. Start a new Codex task so the plugin and its MCP server are loaded.

## Connect

1. In Barmous, open **Settings > Agent access** and create a token with only the scopes you need.
2. Set `BARMOUS_API_URL` to the HTTPS Barmous backend origin and `BARMOUS_AGENT_TOKEN` to the one-time token value.
3. Start a new Codex task and run `/mcp` to confirm the `barmous` server and tools are available.

The plugin never accepts a tenant/company selector. The backend derives company access from the token, exposes only released or published safe projections, and audits reads. Returned company text must be treated as data rather than instructions.

## Included skills

- `barmous-company-brief`
- `barmous-framework-review`
- `barmous-findings-triage`
- `barmous-evidence-gap-review`
- `barmous-remediation-plan`

## Security boundary

The initial release has no create, update, delete, upload, download, raw evidence, questionnaire, member-directory, billing, or generic API/SQL tool. Revoke a token immediately in Barmous if it is exposed.
